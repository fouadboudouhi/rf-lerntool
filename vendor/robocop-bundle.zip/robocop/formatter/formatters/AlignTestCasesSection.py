from __future__ import annotations

from typing import TYPE_CHECKING

from robot.parsing.model.statements import Template

from robocop.exceptions import InvalidParameterValueError
from robocop.formatter.disablers import skip_if_disabled
from robocop.formatter.formatters.aligners_core import AlignKeywordsTestsSection
from robocop.formatter.utils.misc import is_suite_templated

if TYPE_CHECKING:
    from robot.parsing.model.blocks import File, KeywordSection, TestCase

TEMPLATED = "templated"
NON_TEMPLATED = "non_templated"


class AlignTestCasesSection(AlignKeywordsTestsSection):
    """
    Align ``*** Test Cases ***`` section to columns.

    Align non-templated tests and settings into columns with predefined width. There are two possible alignment types
    (configurable via ``alignment_type``):
      - ``fixed`` (default): pad the tokens to the fixed width of the column
      - ``auto``: pad the tokens to the width of the longest token in the column

    Example output:
    ```robotframework
    *** Test Cases ***
    Test
        ${var}        Create Resource       ${argument}       value
        Assert        value
        Multi
        ...           line
        ...           args
    ```

    Column widths can be configured via ``widths`` (default ``24``). It accepts comma separated list of column widths.

    Tokens that are longer than width of the column go into "overflow" state. It's possible to decide in this
    situation (by configuring ``handle_too_long``):
      - ``overflow`` (default): align token to the next column
      - ``compact_overflow``: try to fit next token between current (overflowed) token and next column
      - ``ignore_rest``: ignore remaining tokens in the line
      - ``ignore_line``: ignore whole line

    It is possible to skip formatting on various types of the syntax (documentation, keyword calls with specific names
    or settings).

    You can limit alignment to only templated tests (tests with ``[Template]`` setting) or only non-templated tests
    by configuring ``test_types``. It accepts a comma separated list with the ``templated`` and ``non_templated``
    values. By default both test types are aligned.
    """

    def __init__(
        self,
        widths: str = "",
        alignment_type: str = "fixed",
        handle_too_long: str = "overflow",
        compact_overflow_limit: int = 2,
        align_comments: bool = False,
        align_settings_separately: bool = False,
        test_types: str = "templated,non_templated",
        skip_documentation: str = "True",  # noqa: ARG002 override skip_documentation from Skip
    ) -> None:
        self.test_types = self.parse_test_types(test_types)
        super().__init__(
            widths, alignment_type, handle_too_long, compact_overflow_limit, align_comments, align_settings_separately
        )

    def parse_test_types(self, test_types: str) -> set[str]:
        allowed = {TEMPLATED, NON_TEMPLATED}
        parsed = {value.strip().lower() for value in test_types.split(",") if value.strip()}
        if not parsed or not parsed.issubset(allowed):
            raise InvalidParameterValueError(
                self.__class__.__name__,
                "test_types",
                test_types,
                f"Test types should be comma separated list of at least one of the following values: "
                f"'{TEMPLATED}', '{NON_TEMPLATED}'.",
            )
        return parsed

    def visit_File(self, node: File) -> File:  # noqa: N802
        if is_suite_templated(node):
            return node
        return super().visit_File(node)

    @skip_if_disabled
    def visit_TestCase(self, node: TestCase) -> TestCase:  # noqa: N802
        test_type = TEMPLATED if self.is_templated_test(node) else NON_TEMPLATED
        if test_type not in self.test_types:
            return node
        self.create_auto_widths_for_context(node)
        self.generic_visit(node)
        self.remove_auto_widths_for_context()
        return node

    @staticmethod
    def is_templated_test(node: TestCase) -> bool:
        return any(isinstance(statement, Template) for statement in node.body)

    def visit_KeywordSection(self, node: KeywordSection) -> KeywordSection:  # noqa: N802
        # do nothing -> stop a visitor from visiting other sections for performance
        return node

    visit_SettingSection = visit_KeywordSection  # noqa: N815
